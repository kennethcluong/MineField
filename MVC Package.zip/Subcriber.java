public interface Subscriber {
	void update();
}
